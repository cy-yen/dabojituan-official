var num={
    getLocal(name) {
        return JSON.parse(localStorage.getItem(name))
    },
    setLocal(name, val) {
        localStorage.setItem(name, JSON.stringify(val))
    },
},downloadCount=parseInt(num.getLocal('downloadCount'))||68773,scoreCount=parseInt(num.getLocal('scoreCount'))||5643;
downloadCount=downloadCount+Math.floor(Math.random()*(1 - 50) + 50)
scoreCount=scoreCount+Math.floor(Math.random()*(1 - 50) + 50)

var loadCurrentApp={
    appId: 43,
    appName: "太阳城858558.com",//网址名称
    appLogoPath: "./img/tyc0725_logo.png",//appLogo
    appBannerPath: "./img/tyc0725_banner.png",//头部背景
    appInformation: "推荐用户下载手机APP，防劫持、防跳转！娱乐无忧，随时随地畅享游戏乐趣。全面支持：存取款、游戏下注、优惠申请、在线客服...",//描述
    appEffectList: [
        "./img/500xc_effect_1.png",
        "./img/500xc_effect_2.png",
        "./img/500xc_effect_3.png",
        "./img/500xc_effect_4.png",
        "./img/500xc_effect_5.png"
    ],//尾部輪播
    appVersion: "v1.20",//版本
    isAppVersionJs: false,//是否有极速版app
    appScore: 4.9,//評分star
    scoreCount,//评分人数
    appAndroidPath: "https://myappdownhk.oss-cn-hongkong.aliyuncs.com/120383/858558.com.1.8.ys.apk", //Android下載地址
    jsAppAndroidPath: "https://api1.tyc120383api.com/down/858558.com.apk", //极速Android下載地址
    helpHref: "https://a16.chatsets.com/chat/chatClient/chatbox.jsp?companyID=1222345&configID=3849&jid=4688412749&s=1",//客服
    appHomeUrl: "https://www.858558.com/",//官网地址
    codeUrl: "https://www.858558.com/down/app/",//二维码链接 *链接为图片时 仅支持填入 gif|jpg|jpeg|png|GIF|JPG|PNG 等格式
    qrCodeLogo: "./img/tyc0725_logo.png",//二维码logo
    appDownloadPath: "itms-services://?action=download-manifest&url=https://api1.tyc120383api.com/down/iosys/manifest.plist",//ios下載地址
    jsAppDownloadPath: "itms-services://?action=download-manifest&url=https://api1.tyc120383api.com/down/ios/manifest.plist",//极速ios下載地址
    downloadCount,//下载数量
    mobileprovision: 'https://api1.tyc120383api.com/down/858558.mobileprovision'//信任证书
}


num.setLocal('downloadCount',loadCurrentApp.downloadCount)
num.setLocal('scoreCount',loadCurrentApp.scoreCount)
function getAppDownload(e) {
    var u = navigator.userAgent;
    var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
    var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端


    if (isAndroid == true) {
        return {
            url:e.appAndroidPath,
            jsUrl:e.jsAppAndroidPath,
        }
    } else if (isiOS == true) {
        return {
            url:e.appDownloadPath,
            jsUrl:e.jsAppDownloadPath,
        }
    }else {
        return {
            url:e.appAndroidPath,
            jsUrl:e.jsAppAndroidPath,
        }
    }
}
